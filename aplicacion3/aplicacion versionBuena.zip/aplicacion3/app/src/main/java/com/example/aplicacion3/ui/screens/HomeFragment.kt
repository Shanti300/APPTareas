package com.example.aplicacion3.ui.screens

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.compose.foundation.background
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.aplicacion3.R
import com.example.aplicacion3.data.AppPreferences
import com.example.aplicacion3.model.Task
import com.example.aplicacion3.ui.components.TaskItem
import com.example.aplicacion3.ui.theme.ThemeManager
import com.example.aplicacion3.viewmodel.TaskViewModel

class HomeFragment : Fragment() {
    private lateinit var viewModel: TaskViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        viewModel = ViewModelProvider(this).get(TaskViewModel::class.java)

        // Inicializar ThemeManager con las preferencias
        val appPreferences = AppPreferences(requireContext())
        ThemeManager.initialize(appPreferences)

        val composeView = view.findViewById<ComposeView>(R.id.compose_content)
        composeView.setContent {
            val tasks by viewModel.tasks.collectAsState(initial = emptyList())
            val backgroundColor by ThemeManager.backgroundColor.collectAsState()

            LazyColumn(
                modifier = Modifier.background(backgroundColor)
            ) {
                items(tasks) { task ->
                    TaskItem(task = task, onTaskCompletionChange = { isChecked ->
                        viewModel.updateTaskCompletion(task, isChecked)
                    })
                }
            }
        }

        val navController = findNavController()

        view.findViewById<Button>(R.id.button_go_to_details).setOnClickListener {
            navController.navigate(R.id.detailsFragment)
        }

        view.findViewById<Button>(R.id.button_settings).setOnClickListener {
            navController.navigate(R.id.settingsFragment)
        }

        val editTextNewTask = view.findViewById<EditText>(R.id.edit_text_new_task)
        val buttonAddTask = view.findViewById<Button>(R.id.button_add_task)

        buttonAddTask.setOnClickListener {
            val taskText = editTextNewTask.text.toString()
            if (taskText.isNotBlank()) {
                viewModel.addTask(taskText)
                editTextNewTask.text.clear()
            }
        }
        return view
    }
}