package com.example.aplicacion3.ui.theme

import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import com.example.aplicacion3.data.AppPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object ThemeManager {
    // StateFlow para ser observado por todos los componentes
    private val _backgroundColor = MutableStateFlow(Color.White)
    val backgroundColor: StateFlow<Color> = _backgroundColor.asStateFlow()

    // Inicializar con el valor guardado en SharedPreferences
    fun initialize(appPreferences: AppPreferences) {
        _backgroundColor.value = appPreferences.getBackgroundColor()
    }

    // Actualizar el color de fondo
    fun updateBackgroundColor(color: Color, appPreferences: AppPreferences) {
        _backgroundColor.value = color
        appPreferences.saveBackgroundColor(color)
    }
}