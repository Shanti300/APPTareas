package com.example.aplicacion3.model

data class Task(
    val id: Int? = null, // Opcional: ID único de la tarea (si usas una base de datos)
    val description: String,
    val isCompleted: Boolean = false  // Valor por defecto: tarea no completada
)