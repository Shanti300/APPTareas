package com.example.aplicacion3.ui.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class DetailsViewModel : ViewModel() {

    private val _detailsText = MutableLiveData("Esta es la información de detalles")
    val detailsText: LiveData<String> = _detailsText

    fun updateDetails(newText: String) {
        _detailsText.value = newText
    }
}
