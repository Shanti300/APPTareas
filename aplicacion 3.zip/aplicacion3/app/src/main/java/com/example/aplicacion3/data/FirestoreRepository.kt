package com.example.aplicacion3.data

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.example.aplicacion3.model.Task
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow

class FirestoreRepository {
    private val db = FirebaseFirestore.getInstance()
    private val tasksCollection = db.collection("tasks")

    // Flow para observar cambios en la colección de tareas
    fun getTasks(): Flow<List<Task>> = callbackFlow {
        val subscription = tasksCollection
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    // Manejar error
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    val tasks = snapshot.documents.mapNotNull { doc ->
                        doc.toObject(Task::class.java)?.copy(id = doc.id)
                    }
                    trySend(tasks)
                }
            }

        // Cerrar el listener cuando el flow se cierre
        awaitClose { subscription.remove() }
    }

    // Agregar una nueva tarea
    suspend fun addTask(title: String): Result<Task> = withContext(Dispatchers.IO) {
        try {
            val task = Task(
                id = "",  // Firestore generará un ID
                title = title,
                isCompleted = false,
                timestamp = System.currentTimeMillis()
            )

            // Crear un mapa para Firestore (sin ID)
            val taskMap = hashMapOf(
                "title" to task.title,
                "isCompleted" to task.isCompleted,
                "timestamp" to task.timestamp
            )

            val docRef = tasksCollection.add(taskMap).await()
            Result.success(task.copy(id = docRef.id))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Actualizar una tarea existente
    suspend fun updateTask(task: Task): Result<Task> = withContext(Dispatchers.IO) {
        try {
            tasksCollection.document(task.id)
                .set(task)
                .await()
            Result.success(task)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Actualizar solo el estado de completado de una tarea
    suspend fun updateTaskCompletion(taskId: String, isCompleted: Boolean): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            tasksCollection.document(taskId)
                .update("isCompleted", isCompleted)
                .await()
            Result.success(isCompleted)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Eliminar una tarea
    suspend fun deleteTask(taskId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            tasksCollection.document(taskId)
                .delete()
                .await()
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}