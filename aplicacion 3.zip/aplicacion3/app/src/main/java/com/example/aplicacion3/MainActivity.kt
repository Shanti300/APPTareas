package com.example.aplicacion3

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializar Firebase
        FirebaseApp.initializeApp(this)
        auth = FirebaseAuth.getInstance()

        setContentView(R.layout.activity_main)

        val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController

        // Verificar si hay un usuario logueado al iniciar
        val currentUser = auth.currentUser
        if (currentUser == null) {
            // No hay usuario logueado, ir a la pantalla de login
            navController.navigate(R.id.loginFragment)
        }
    }

    override fun onResume() {
        super.onResume()
        // Verificar si el usuario cerró sesión mientras la app estaba en segundo plano
        if (auth.currentUser == null) {
            val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
            val navController = navHostFragment.navController
            if (navController.currentDestination?.id != R.id.loginFragment &&
                navController.currentDestination?.id != R.id.registerFragment) {
                navController.navigate(R.id.loginFragment)
            }
        }
    }
}