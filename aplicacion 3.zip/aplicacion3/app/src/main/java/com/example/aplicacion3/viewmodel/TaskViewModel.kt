package com.example.aplicacion3.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aplicacion3.data.FirestoreRepository
import com.example.aplicacion3.model.Task
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class TaskViewModel : ViewModel() {
    private val repository = FirestoreRepository()

    // Usando el Flow directamente desde el repositorio
    val tasks: Flow<List<Task>> = repository.getTasks()

    // Estado para manejar errores o mensajes
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    // Estado para indicar carga
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // Agregar una nueva tarea
    fun addTask(title: String) {
        if (title.isBlank()) return

        viewModelScope.launch {
            _isLoading.value = true
            try {
                repository.addTask(title)
                // El listener de Firestore actualizará automáticamente la lista
            } catch (e: Exception) {
                _message.value = "Error al agregar tarea: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    // Actualizar el estado de completado de una tarea
    fun updateTaskCompletion(task: Task, isCompleted: Boolean) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                repository.updateTaskCompletion(task.id, isCompleted)
                // El listener de Firestore actualizará automáticamente la tarea
            } catch (e: Exception) {
                _message.value = "Error al actualizar tarea: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    // Eliminar una tarea
    fun deleteTask(task: Task) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                repository.deleteTask(task.id)
                // El listener de Firestore actualizará automáticamente la lista
            } catch (e: Exception) {
                _message.value = "Error al eliminar tarea: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    // Limpiar mensaje de error
    fun clearMessage() {
        _message.value = null
    }
}