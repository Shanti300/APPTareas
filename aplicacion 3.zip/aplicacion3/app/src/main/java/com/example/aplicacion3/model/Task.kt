
package com.example.aplicacion3.model

// Esta clase es compatible con Firestore
data class Task(
    val id: String = "", // ID único para Firestore
    val title: String = "",
    val isCompleted: Boolean = false,
    val timestamp: Long = System.currentTimeMillis() // Para ordenar por fecha
) {
    // Constructor sin argumentos requerido para Firestore
    constructor() : this("", "", false, 0)

    // Para convertir desde el modelo actual si ya tienes uno
    constructor(task: Task) : this(
        task.id,
        task.title,
        task.isCompleted,
        System.currentTimeMillis()
    )
}